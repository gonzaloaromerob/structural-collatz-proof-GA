# collatz_simulator.py

def collatz_step(n):
    if n % 2 == 0:
        return n // 2
    else:
        return (3 * n + 1) // 2

def full_trajectory(n):
    trajectory = [n]
    while n != 1:
        n = collatz_step(n)
        trajectory.append(n)
    return trajectory
