# Structural Proof of the Collatz Conjecture via G+A Model

This repository contains the code, data, and validation framework supporting the structural proof of the Collatz conjecture using a hybrid human-AI (G+A) approach.

## Contents

- `collatz_simulator.py`: Core implementation of the Collatz transformation and DAG generation.
- `collatz_dag_proof.ipynb`: Jupyter notebook demonstrating the step-by-step validation using Φ(n).
- `sha_validation.py`: Script to compute SHA-256 hashes for trajectory uniqueness.
- `requirements.txt`: Required Python libraries.
- `graphs/`: Compressed graphs in `.gpickle` format (optional).

## Reproducibility

Run the notebook in any Python 3.11+ environment. DAG rendering and analysis work best with NetworkX and Matplotlib.

## License

MIT License.
